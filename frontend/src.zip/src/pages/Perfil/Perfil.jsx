
import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Lock, Plus, X } from '@phosphor-icons/react'

import styles from './Perfil.module.css'
import { interesses, salasPorInteresse } from '../../data/salas'

import avatarUm from '../../assets/avatars/1.png'
import avatarDois from '../../assets/avatars/2.png'
import avatarTres from '../../assets/avatars/3.png'
import avatarQuatro from '../../assets/avatars/4.png'
import avatarCinco from '../../assets/avatars/5.png'
import avatarSeis from '../../assets/avatars/6.png'
import avatarSete from '../../assets/avatars/7.png'
import avatarOito from '../../assets/avatars/8.png'

import avatarNove from '../../assets/avatars/9.png'
import avatarDez from '../../assets/avatars/10.png'
import avatarOnze from '../../assets/avatars/11.png'
import avatarDoze from '../../assets/avatars/12.png'
import avatarTreze from '../../assets/avatars/13.png'
import avatarQuatorze from '../../assets/avatars/14.png'
import avatarQuinze from '../../assets/avatars/15.png'
import avatarDezesseis from '../../assets/avatars/16.png'

const avataresPadrao = [
    { id: 1, imagem: avatarUm },
    { id: 2, imagem: avatarDois },
    { id: 3, imagem: avatarTres },
    { id: 4, imagem: avatarQuatro },
    { id: 5, imagem: avatarCinco },
    { id: 6, imagem: avatarSeis },
    { id: 7, imagem: avatarSete },
    { id: 8, imagem: avatarOito }
]

const avataresFiap = [
    { id: 9, imagem: avatarNove },
    { id: 10, imagem: avatarDez },
    { id: 11, imagem: avatarOnze },
    { id: 12, imagem: avatarDoze },
    { id: 13, imagem: avatarTreze },
    { id: 14, imagem: avatarQuatorze },
    { id: 15, imagem: avatarQuinze },
    { id: 16, imagem: avatarDezesseis }
]

const avataresPorId = {
    1: avatarUm,
    2: avatarDois,
    3: avatarTres,
    4: avatarQuatro,
    5: avatarCinco,
    6: avatarSeis,
    7: avatarSete,
    8: avatarOito,
    9: avatarNove,
    10: avatarDez,
    11: avatarOnze,
    12: avatarDoze,
    13: avatarTreze,
    14: avatarQuatorze,
    15: avatarQuinze,
    16: avatarDezesseis
}

const tagsPredefinidas = interesses.map((interesse) => ({
    interesse,
    tag: salasPorInteresse[interesse].tag
}))

function obterPerfilSalvo() {
    try {
        return JSON.parse(localStorage.getItem('trocaiPerfil')) || {}
    } catch {
        return {}
    }
}

export default function Perfil() {
    const location = useLocation()

    const [perfilInicial] = useState(obterPerfilSalvo)

    const [nome] = useState('Ana Beatriz Souza Almeida')
    const [curso] = useState('Análise e Desenvolvimento de Sistemas')

    // O apelido começa vazio, exceto se já tiver sido salvo anteriormente.
    const [apelido, setApelido] = useState(
        perfilInicial.apelido || ''
    )

    const [sobreMim, setSobreMim] = useState(
        perfilInicial.sobreMim || ''
    )

    // Recupera o avatar escolhido no cadastro.
    const [avatarAtual, setAvatarAtual] = useState(
        perfilInicial.avatar || { tipo: 'padrao', id: 2 }
    )

    // Define quais avatares aparecem de acordo com o tema ativo.
    const tema = localStorage.getItem('trocaiTema')
    const avatares = tema === 'fiap' ? avataresFiap : avataresPadrao

    const avatarImg = avatarAtual.tipo === 'personalizado'
        ? avatarAtual.imagem
        : avataresPorId[avatarAtual.id] || avatarDois

    // Controle do modal de avatar.
    const [modalAvatarAberto, setModalAvatarAberto] = useState(false)
    const [avatarEmEdicao, setAvatarEmEdicao] = useState(avatarAtual)
    const [erroImagem, setErroImagem] = useState('')

    // Tags personalizadas criadas pelo usuário.
    const [tagsPersonalizadas, setTagsPersonalizadas] = useState(
        perfilInicial.tagsPersonalizadas || []
    )

    // Recupera as tags selecionadas no cadastro e em edições anteriores.
    const [tagsSelecionadas, setTagsSelecionadas] = useState(() => {
        const interessesSalvos = perfilInicial.interesses || []

        const tagsSalvas = interessesSalvos
            .map((interesse) => salasPorInteresse[interesse]?.tag)
            .filter(Boolean)

        const tagsCustomizadasSalvas =
            perfilInicial.tagsSelecionadasPersonalizadas || []

        return [...tagsSalvas, ...tagsCustomizadasSalvas]
    })

    const [novaTagInput, setNovaTagInput] = useState('')
    const [salvo, setSalvo] = useState(false)

    const tags = [
        ...tagsPredefinidas.map((item) => item.tag),
        ...tagsPersonalizadas
    ]

    // Abre o modal usando o avatar atualmente selecionado.
    function abrirModalAvatar() {
        setAvatarEmEdicao(avatarAtual)
        setErroImagem('')
        setModalAvatarAberto(true)
    }

    // Seleciona um dos avatares disponíveis no modal.
    function selecionarAvatar(id) {
        setAvatarEmEdicao({
            tipo: 'padrao',
            id
        })

        setErroImagem('')
    }

    // Faz upload de uma imagem personalizada.
    function adicionarAvatar(event) {
        const arquivo = event.target.files[0]

        if (!arquivo) return

        const formatosPermitidos = [
            'image/png',
            'image/jpeg',
            'image/webp'
        ]

        if (!formatosPermitidos.includes(arquivo.type)) {
            setErroImagem('Selecione uma imagem PNG, JPG ou WebP.')
            event.target.value = ''
            return
        }

        if (arquivo.size > 1024 * 1024) {
            setErroImagem('A imagem deve ter no máximo 1 MB.')
            event.target.value = ''
            return
        }

        const leitor = new FileReader()

        leitor.onload = () => {
            setAvatarEmEdicao({
                tipo: 'personalizado',
                imagem: leitor.result
            })

            setErroImagem('')
        }

        leitor.onerror = () => {
            setErroImagem('Não foi possível carregar a imagem.')
        }

        leitor.readAsDataURL(arquivo)
        event.target.value = ''
    }

    // Confirma a escolha feita no modal.
    function confirmarAvatar() {
        setAvatarAtual(avatarEmEdicao)
        setModalAvatarAberto(false)
        setSalvo(false)
    }

    // Alterna entre selecionar e desselecionar uma tag.
    function handleToggleTag(tag) {
        setTagsSelecionadas((atuais) =>
            atuais.includes(tag)
                ? atuais.filter((item) => item !== tag)
                : [...atuais, tag]
        )

        setSalvo(false)
    }

    // Adiciona uma nova tag personalizada.
    function handleAddTag() {
        if (!novaTagInput.trim()) return

        let formattedTag = novaTagInput.trim()

        if (!formattedTag.startsWith('#')) {
            formattedTag = `#${formattedTag}`
        }

        if (!tags.includes(formattedTag)) {
            setTagsPersonalizadas((atuais) => [
                ...atuais,
                formattedTag
            ])

            setTagsSelecionadas((atuais) => [
                ...atuais,
                formattedTag
            ])
        }

        setNovaTagInput('')
        setSalvo(false)
    }

    // Salva todas as alterações no mesmo registro utilizado pelo cadastro.
    function salvarAlteracoes() {
        const interessesSelecionados = tagsPredefinidas
            .filter((item) => tagsSelecionadas.includes(item.tag))
            .map((item) => item.interesse)

        const tagsCustomizadasSelecionadas = tagsSelecionadas.filter(
            (tag) => !tagsPredefinidas.some((item) => item.tag === tag)
        )

        const perfilAtualizado = {
            ...obterPerfilSalvo(),
            avatar: avatarAtual,
            apelido: apelido.trim(),
            sobreMim,
            interesses: interessesSelecionados,
            tagsPersonalizadas,
            tagsSelecionadasPersonalizadas: tagsCustomizadasSelecionadas
        }

        localStorage.setItem(
            'trocaiPerfil',
            JSON.stringify(perfilAtualizado)
        )
        
        window.dispatchEvent(new Event('trocaiPerfilAtualizado'))

        setSalvo(true)
    }

    // Se a página abrir com #sobre-mim, leva o usuário até a bio.
    useEffect(() => {
        if (location.hash === '#sobre-mim') {
            const campoBio = document.getElementById('sobre-mim')

            if (campoBio) {
                campoBio.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                })

                campoBio.focus({ preventScroll: true })
            }
        }
    }, [location.hash])

    // Fecha o modal ao pressionar Escape.
    useEffect(() => {
        if (!modalAvatarAberto) return

        function fecharComEsc(event) {
            if (event.key === 'Escape') {
                setModalAvatarAberto(false)
            }
        }

        document.addEventListener('keydown', fecharComEsc)

        return () => {
            document.removeEventListener('keydown', fecharComEsc)
        }
    }, [modalAvatarAberto])

    return (
        <section className={styles.container}>
            <header className={styles.perfilHeader}>
                <h1>Meu Perfil e Edição de Identidade</h1>
                <p>É assim que a turma vai te ver na praça.</p>
            </header>

            {/* Seção 1: Avatar e Identidade Visual */}
            <div className={styles.cardSection}>
                <h2>Avatar e Identidade Visual</h2>

                <div className={styles.avatarSectionLayout}>
                    <div className={styles.avatarColumn}>
                        <div className={styles.avatarWrapper}>
                            <img
                                src={avatarImg}
                                alt="Avatar do usuário"
                                className={styles.avatarImg}
                            />
                        </div>

                        <button
                            type="button"
                            className={styles.secondaryButton}
                            onClick={abrirModalAvatar}
                        >
                            Alterar avatar
                        </button>
                    </div>

                    <div className={styles.fieldsColumn}>
                        <div className={styles.inputGroup}>
                            <label>Nome completo</label>

                            <div className={styles.inputWithIcon}>
                                <Lock
                                    size={18}
                                    className={styles.inputIcon}
                                />

                                <input
                                    type="text"
                                    value={nome}
                                    disabled
                                    className={styles.disabledInput}
                                />

                                <span className={styles.inputBadge}>
                                    via SSO
                                </span>
                            </div>
                        </div>

                        <div className={styles.inputGroup}>
                            <label>Curso</label>

                            <div className={styles.inputWithIcon}>
                                <Lock
                                    size={18}
                                    className={styles.inputIcon}
                                />

                                <input
                                    type="text"
                                    value={curso}
                                    disabled
                                    className={styles.disabledInput}
                                />

                                <span className={styles.inputBadge}>
                                    via SSO
                                </span>
                            </div>
                        </div>

                        <div className={styles.inputGroup}>
                            <label>
                                Apelido / Como quero ser chamado
                            </label>

                            <input
                                type="text"
                                value={apelido}
                                onChange={(e) => {
                                    setApelido(e.target.value)
                                    setSalvo(false)
                                }}
                                placeholder="Como você gostaria de ser chamado?"
                                className={styles.standardInput}
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Seção 2: Sobre Mim */}
            <div className={styles.cardSection}>
                <div className={styles.sectionHeaderBetween}>
                    <h2>Sobre Mim</h2>

                    <span className={styles.charCounter}>
                        {sobreMim.length}/140
                    </span>
                </div>

                <textarea
                    id="sobre-mim"
                    maxLength={140}
                    rows={4}
                    placeholder="Conte um pouco sobre você fora das aulas (hobbies, séries, café ou jogos)..."
                    value={sobreMim}
                    onChange={(e) => {
                        setSobreMim(e.target.value)
                        setSalvo(false)
                    }}
                    className={styles.textareaCustom}
                />
            </div>

            {/* Seção 3: Tags de Rotina e Interesses */}
            <div className={styles.cardSection}>
                <h2>Minhas Tags de Rotina e Interesses</h2>

                <div className={styles.tagsContainer}>
                    {tags.map((tag) => {
                        const isSelected = tagsSelecionadas.includes(tag)

                        return (
                            <button
                                key={tag}
                                type="button"
                                onClick={() => handleToggleTag(tag)}
                                aria-pressed={isSelected}
                                className={`${styles.tagBadge} ${
                                    isSelected ? styles.tagHighlight : ''
                                }`}
                            >
                                {tag}
                            </button>
                        )
                    })}
                </div>

                <div className={styles.addTagWrapper}>
                    <input
                        type="text"
                        placeholder="Criar nova tag, ex: #CaféETelaPreta"
                        value={novaTagInput}
                        onChange={(e) => setNovaTagInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                                e.preventDefault()
                                handleAddTag()
                            }
                        }}
                        className={styles.standardInput}
                    />

                    <button
                        type="button"
                        onClick={handleAddTag}
                        className={styles.addTagButton}
                    >
                        <Plus size={16} weight="bold" />
                        Adicionar
                    </button>
                </div>
            </div>

            {/* Ações Inferiores */}
            <div className={styles.formActions}>
                <Link to="/praca" className={styles.btnCancel}>
                    Cancelar
                </Link>

                <button
                    type="button"
                    onClick={salvarAlteracoes}
                    className={styles.btnSave}
                >
                    Salvar Alterações
                </button>
            </div>

            {salvo && (
                <p role="status" className={styles.successMessage}>
                    Alterações salvas com sucesso!
                </p>
            )}

            {/* Modal de seleção de avatar */}
            {modalAvatarAberto && (
                <div
                    className={styles.modalOverlay}
                    onClick={() => setModalAvatarAberto(false)}
                >
                    <div
                        className={styles.modalAvatar}
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="titulo-modal-avatar"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className={styles.modalHeader}>
                            <div>
                                <h2 id="titulo-modal-avatar">
                                    Escolha seu avatar
                                </h2>
                                <p>
                                    Selecione uma imagem para representar você.
                                </p>
                            </div>

                            <button
                                type="button"
                                className={styles.closeModalButton}
                                onClick={() => setModalAvatarAberto(false)}
                                aria-label="Fechar modal"
                            >
                                <X size={22} />
                            </button>
                        </div>

                        <div className={styles.modalAvatares}>
                            {avatares.map((avatar) => (
                                <button
                                    key={avatar.id}
                                    type="button"
                                    onClick={() => selecionarAvatar(avatar.id)}
                                    className={`${styles.avatarOpcao} ${
                                        avatarEmEdicao.tipo === 'padrao' &&
                                        avatarEmEdicao.id === avatar.id
                                            ? styles.avatarOpcaoSelecionada
                                            : ''
                                    }`}
                                    aria-pressed={
                                        avatarEmEdicao.tipo === 'padrao' &&
                                        avatarEmEdicao.id === avatar.id
                                    }
                                    aria-label={`Selecionar avatar ${avatar.id}`}
                                >
                                    <img
                                        src={avatar.imagem}
                                        alt={`Avatar ${avatar.id}`}
                                    />
                                </button>
                            ))}

                            {avatarEmEdicao.tipo === 'personalizado' && (
                                <div
                                    className={`${styles.avatarOpcao} ${styles.avatarOpcaoSelecionada}`}
                                >
                                    <img
                                        src={avatarEmEdicao.imagem}
                                        alt="Avatar personalizado selecionado"
                                    />
                                </div>
                            )}
                        </div>

                        <div className={styles.modalUpload}>
                            <label
                                htmlFor="input-avatar-perfil"
                                className={styles.modalAddButton}
                            >
                                <Plus size={17} weight="bold" />
                                Adicionar imagem
                            </label>

                            <input
                                id="input-avatar-perfil"
                                className={styles.inputArquivo}
                                type="file"
                                accept="image/png, image/jpeg, image/webp"
                                onChange={adicionarAvatar}
                            />
                        </div>

                        {erroImagem && (
                            <p className={styles.erroImagem} role="alert">
                                {erroImagem}
                            </p>
                        )}

                        <div className={styles.modalActions}>
                            <button
                                type="button"
                                className={styles.btnCancel}
                                onClick={() => setModalAvatarAberto(false)}
                            >
                                Cancelar
                            </button>

                            <button
                                type="button"
                                className={styles.btnSave}
                                onClick={confirmarAvatar}
                            >
                                Usar avatar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </section>
    )
}
